import os
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parents[2]
load_dotenv(BASE_DIR / ".env")

SECRET_KEY = os.getenv("DJANGO_SECRET_KEY")
if not SECRET_KEY:
    SECRET_KEY = "dev-only-change-me"

IS_VERCEL = bool(os.getenv("VERCEL"))
DEBUG = (
    not IS_VERCEL
    and os.getenv("DJANGO_DEBUG", "True").lower() == "true"
)
VERCEL_HOSTS = [
    os.getenv(name, "").strip()
    for name in (
        "VERCEL_URL",
        "VERCEL_BRANCH_URL",
        "VERCEL_PROJECT_PRODUCTION_URL",
    )
    if os.getenv(name, "").strip()
]
VERCEL_HOSTS.append(".vercel.app")
configured_allowed_hosts = [
    host.strip()
    for host in os.getenv(
        "DJANGO_ALLOWED_HOSTS", "127.0.0.1,localhost"
    ).split(",")
    if host.strip()
]
ALLOWED_HOSTS = list(dict.fromkeys(configured_allowed_hosts + VERCEL_HOSTS))
CSRF_TRUSTED_ORIGINS = [
    origin.strip()
    for origin in os.getenv("CSRF_TRUSTED_ORIGINS", "").split(",")
    if origin.strip()
]
CSRF_TRUSTED_ORIGINS = list(
    dict.fromkeys(
        CSRF_TRUSTED_ORIGINS
        + [f"https://{host}" for host in VERCEL_HOSTS]
    )
)

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "booking",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "booking.middleware.VercelConfigurationMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "frontend" / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]
WSGI_APPLICATION = "config.wsgi.application"

DATABASE_URL = (
    os.getenv("DATABASE_URL")
    or os.getenv("POSTGRES_URL")
    or os.getenv("MYSQL_URL")
    or ""
).strip()
DB_SSL = os.getenv("DB_SSL", "").lower() == "true"


def _mysql_options(use_ssl):
    options = {"charset": "utf8mb4"}
    if use_ssl:
        # Hosted MySQL (TiDB Cloud, Aiven, etc.) requires TLS; PyMySQL verifies
        # the server certificate against the system CA bundle.
        options["ssl"] = {"check_hostname": True}
    return options


if DATABASE_URL:
    # One connection string, e.g. from a Vercel Marketplace database (Neon Postgres)
    # or a hosted MySQL provider: postgres://... or mysql://...
    _url = urlparse(DATABASE_URL)
    _scheme = _url.scheme.split("+")[0]
    _query = parse_qs(_url.query)
    if _scheme in ("postgres", "postgresql"):
        DATABASES = {
            "default": {
                "ENGINE": "django.db.backends.postgresql",
                "NAME": unquote(_url.path.lstrip("/")),
                "USER": unquote(_url.username or ""),
                "PASSWORD": unquote(_url.password or ""),
                "HOST": _url.hostname,
                "PORT": _url.port or 5432,
                "OPTIONS": {"sslmode": _query.get("sslmode", ["require"])[0]},
                "CONN_MAX_AGE": 0,
            }
        }
    elif _scheme == "mysql":
        _ssl = DB_SSL or any(
            key in _query for key in ("ssl", "ssl-mode", "sslmode", "ssl_mode")
        )
        DATABASES = {
            "default": {
                "ENGINE": "django.db.backends.mysql",
                "NAME": unquote(_url.path.lstrip("/")),
                "USER": unquote(_url.username or ""),
                "PASSWORD": unquote(_url.password or ""),
                "HOST": _url.hostname,
                "PORT": _url.port or 3306,
                "OPTIONS": _mysql_options(_ssl),
            }
        }
    else:
        raise ValueError(
            f"Unsupported DATABASE_URL scheme '{_url.scheme}'. Use postgres:// or mysql://."
        )
elif os.getenv("DB_ENGINE", "sqlite").lower() == "mysql":
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.mysql",
            "NAME": os.getenv("DB_NAME", "dominic"),
            "USER": os.getenv("DB_USER", "root"),
            "PASSWORD": os.getenv("DB_PASSWORD", ""),
            "HOST": os.getenv("DB_HOST", "127.0.0.1"),
            "PORT": os.getenv("DB_PORT", "3306"),
            "OPTIONS": _mysql_options(DB_SSL),
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / os.getenv("DB_NAME", "dominic.sqlite3"),
        }
    }

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]
LANGUAGE_CODE = "en-us"
TIME_ZONE = "Asia/Kolkata"
USE_I18N = True
USE_TZ = True

STATIC_URL = "/static/"
STATICFILES_DIRS = [BASE_DIR / "frontend" / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"
MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"
# Uploaded images: saved to Vercel Blob when a Blob store is connected (it sets
# BLOB_READ_WRITE_TOKEN); otherwise to the local media/ folder.
USE_VERCEL_BLOB = bool(os.getenv("BLOB_READ_WRITE_TOKEN"))
STORAGES = {
    "default": {
        "BACKEND": (
            "booking.storage.VercelBlobStorage"
            if USE_VERCEL_BLOB
            else "django.core.files.storage.FileSystemStorage"
        ),
    },
    "staticfiles": {
        "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
    },
}
if not DEBUG:
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
LOGIN_URL = "login"
LOGIN_REDIRECT_URL = "home"
LOGOUT_REDIRECT_URL = "home"
DEFAULT_FROM_EMAIL = os.getenv("EMAIL_USER", "dominicericson2701@gmail.com")
DEVELOPER_EMAIL = os.getenv("DEVELOPER_EMAIL", "dominicericson2701@gmail.com").lower()
DEVELOPER_PASSWORD_HASH = os.getenv("DEVELOPER_PASSWORD_HASH", "")
EMAIL_BACKEND = os.getenv("EMAIL_BACKEND", "django.core.mail.backends.smtp.EmailBackend")
EMAIL_HOST = os.getenv("EMAIL_HOST", "smtp.gmail.com")
EMAIL_PORT = int(os.getenv("EMAIL_PORT", "587"))
EMAIL_HOST_USER = os.getenv("EMAIL_USER", "dominicericson2701@gmail.com")
EMAIL_HOST_PASSWORD = os.getenv("EMAIL_PASSWORD", "")
EMAIL_USE_TLS = os.getenv("EMAIL_USE_TLS", "True").lower() == "true"
